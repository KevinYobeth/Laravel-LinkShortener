<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Laravel</title>

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">

</head>

<body class="antialiased">
    <div class="relative flex justify-center min-h-screen bg-gray-100 sm:items-center sm:pt-0">
        <div>
            <div>
                <?php if(Session::has('link')): ?>
                <div class="flex bg-white h-10 w-full items-center mb-5">
                    <div class="bg-green-400 h-10 w-2"></div>
                    <p class="ml-2">
                        <a href="<?php echo e(Session::get('link')); ?>"><?php echo e(Session::get('link')); ?></a>
                    </p>
                </div>
                <?php endif; ?>
                <form action="<?php echo e(route('addLink')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="flex w-full mb-3">
                        <input
                            class="bg-gray-200 appearance-none border-2 border-gray-200 rounded w-full py-2 px-4 text-gray-700 leading-tight focus:outline-none focus:bg-white focus:border-yellow-300 transition ease-out duration-300"
                            id="urlToShorten" name="urlToShorten" type="url">
                        <button
                            class="shadow bg-yellow-300 hover:bg-yellow-400 focus:shadow-outline focus:outline-none text-gray-700 font-bold py-2 px-4 rounded"
                            type="submit">
                            Shorten!
                        </button>
                    </div>
                </form>
            </div>


            <?php if(Route::has('login')): ?>
            <div class="flex justify-center">
                <?php if(auth()->guard()->check()): ?>
                <a href="<?php echo e(url('/dashboard')); ?>" class="text-sm text-gray-900">Dashboard</a>
                <?php else: ?>
                <a href="<?php echo e(route('login')); ?>" class="text-sm text-gray-900 hover:underline mr-3">Sign
                    In</a>

                <?php if(Route::has('register')): ?>
                <a href="<?php echo e(route('register')); ?>" class="text-sm text-gray-900 hover:underline">Register</a>
                <?php endif; ?>
                <?php endif; ?>
            </div>
            <?php endif; ?>
        </div>

    </div>
    <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html><?php /**PATH C:\xampp\htdocs\linkShortener\resources\views/welcome.blade.php ENDPATH**/ ?>